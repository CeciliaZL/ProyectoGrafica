/*
Pr�ctica 7: Iluminaci�n 1 
*/
//para cargar imagen
#define STB_IMAGE_IMPLEMENTATION

#include <stdio.h>
#include <string.h>
#include <cmath>
#include <vector>
#include <math.h>

#include <glew.h>
#include <glfw3.h>
#include <iomanip>

#include <glm.hpp>
#include <gtc\matrix_transform.hpp>
#include <gtc\type_ptr.hpp>
//para probar el importer
//#include<assimp/Importer.hpp>

#include "Window.h"
#include "Mesh.h"
#include "Shader_light.h"
#include "Camera.h"
#include "Texture.h"
#include "Sphere.h"
#include"Model.h"
#include "Skybox.h"

//para iluminaci�n
#include "CommonValues.h"
#include "DirectionalLight.h"
#include "PointLight.h"
#include "SpotLight.h"
#include "Material.h"
const float toRadians = 3.14159265f / 180.0f;

Window mainWindow;
std::vector<Mesh*> meshList;
std::vector<Shader> shaderList;

Camera camera;

Texture brickTexture;
Texture dirtTexture;
Texture plainTexture;
Texture pisoTexture;
Texture AgaveTexture;
Texture dadoTexture;
Texture luchadorTexture;

Model Lamp_M;
Model Auto_Cofre;
Model Rico_M;
Model JessieLamp_M;
Model JessieLamp2_M;
Model Entrada_M;
Model Estante_M;
//Brawl Objects
Model Piper_M;
Model Spike_M;
Model Cordelius_M;
Model Frank_M;
Model Gus_M;
Model Stu_M;
Model Sam_M;
Model Colette_M;
Model Surge_M;
Model Brock_M;
Model Doug_M;
Model SamYeti_M;
Model SpikeFire_M;
Model SpikeSakura_M;
Model Dynamike_M;
Model Gale_M;
Model DougDraco_M;
Model Meg_M;
Model Jessie_M;

//Luchadores
Model Luchador_M;
Model Luchador2_M;
Model Luchador3_M;
//Modelos animaci�n luchador
Model Luchador3_M1;
Model Luchador3_M2;
Model Luchador3_M3;
Model Luchador3_M4;
Model Luchador3_M5;
Model Luchador3_M6;
Model Luchador3_M7;
Model Luchador3_M8;
Model Luchador3_M9;

Model Pedestal_M;
Model Carrito_M;
Model Mask_M;
Model Mask2_M;
Model Mask3_M;
Model Mask4_M;
Model Mask5_M;
Model Bulls_M;
Model Ochobit_M;

//NUEVOS MODELOS
Model Carl_M;
Model Primo1_M;
Model Primo2_M;
Model Primo3_M;
Model Arts_M;
Model Bala_M;
//Fin de nuevos modelos

Skybox skybox;

//materiales
Material Material_brillante;
Material Material_opaco;


//Sphere cabeza = Sphere(0.5, 20, 20);
GLfloat deltaTime = 0.0f;
GLfloat lastTime = 0.0f;
static double limitFPS = 1.0 / 60.0;
bool luzAntorchaEncendida = true;

// luz direccional
DirectionalLight mainLight;
//para declarar varias luces de tipo pointlight
PointLight pointLights[MAX_POINT_LIGHTS];
PointLight pointLights2[MAX_POINT_LIGHTS];
SpotLight spotLights[MAX_SPOT_LIGHTS];
SpotLight spotLights2[MAX_SPOT_LIGHTS];

// Vertex Shader
static const char* vShader = "shaders/shader_light.vert";

// Fragment Shader
static const char* fShader = "shaders/shader_light.frag";


//funci�n de calculo de normales por promedio de v�rtices 
void calcAverageNormals(unsigned int* indices, unsigned int indiceCount, GLfloat* vertices, unsigned int verticeCount,
	unsigned int vLength, unsigned int normalOffset)
{
	for (size_t i = 0; i < indiceCount; i += 3)
	{
		unsigned int in0 = indices[i] * vLength;
		unsigned int in1 = indices[i + 1] * vLength;
		unsigned int in2 = indices[i + 2] * vLength;
		glm::vec3 v1(vertices[in1] - vertices[in0], vertices[in1 + 1] - vertices[in0 + 1], vertices[in1 + 2] - vertices[in0 + 2]);
		glm::vec3 v2(vertices[in2] - vertices[in0], vertices[in2 + 1] - vertices[in0 + 1], vertices[in2 + 2] - vertices[in0 + 2]);
		glm::vec3 normal = glm::cross(v1, v2);
		normal = glm::normalize(normal);

		in0 += normalOffset; in1 += normalOffset; in2 += normalOffset;
		vertices[in0] += normal.x; vertices[in0 + 1] += normal.y; vertices[in0 + 2] += normal.z;
		vertices[in1] += normal.x; vertices[in1 + 1] += normal.y; vertices[in1 + 2] += normal.z;
		vertices[in2] += normal.x; vertices[in2 + 1] += normal.y; vertices[in2 + 2] += normal.z;
	}

	for (size_t i = 0; i < verticeCount / vLength; i++)
	{
		unsigned int nOffset = i * vLength + normalOffset;
		glm::vec3 vec(vertices[nOffset], vertices[nOffset + 1], vertices[nOffset + 2]);
		vec = glm::normalize(vec);
		vertices[nOffset] = vec.x; vertices[nOffset + 1] = vec.y; vertices[nOffset + 2] = vec.z;
	}
}


void CreateObjects()
{
	unsigned int indices[] = {
		0, 3, 1,
		1, 3, 2,
		2, 3, 0,
		0, 1, 2
	};

	GLfloat vertices[] = {
		//	x      y      z			u	  v			nx	  ny    nz
			-1.0f, -1.0f, -0.6f,	0.0f, 0.0f,		0.0f, 0.0f, 0.0f,
			0.0f, -1.0f, 1.0f,		0.5f, 0.0f,		0.0f, 0.0f, 0.0f,
			1.0f, -1.0f, -0.6f,		1.0f, 0.0f,		0.0f, 0.0f, 0.0f,
			0.0f, 1.0f, 0.0f,		0.5f, 1.0f,		0.0f, 0.0f, 0.0f
	};

	unsigned int floorIndices[] = {
		0, 2, 1,
		1, 2, 3
	};

	GLfloat floorVertices[] = {
		-10.0f, 0.0f, -10.0f,	1.0f, 1.0f,	0.0f, -1.0f, 0.0f,
		10.0f, 0.0f, -10.0f,	1.0f, 0.0f,	0.0f, -1.0f, 0.0f,
		-10.0f, 0.0f, 10.0f,	0.0f, 1.0f,	0.0f, -1.0f, 0.0f,
		10.0f, 0.0f, 10.0f,		0.0f, 0.0f,	0.0f, -1.0f, 0.0f
	};

	unsigned int vegetacionIndices[] = {
	   0, 1, 2,
	   0, 2, 3,
	   4,5,6,
	   4,6,7
	};

	GLfloat vegetacionVertices[] = {
		-0.5f, -0.5f, 0.0f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f,
		0.5f, -0.5f, 0.0f,		1.0f, 0.0f,		0.0f, 0.0f, 0.0f,
		0.5f, 0.5f, 0.0f,		1.0f, 1.0f,		0.0f, 0.0f, 0.0f,
		-0.5f, 0.5f, 0.0f,		0.0f, 1.0f,		0.0f, 0.0f, 0.0f,

		0.0f, -0.5f, -0.5f,		0.0f, 0.0f,		0.0f, 0.0f, 0.0f,
		0.0f, -0.5f, 0.5f,		1.0f, 0.0f,		0.0f, 0.0f, 0.0f,
		0.0f, 0.5f, 0.5f,		1.0f, 1.0f,		0.0f, 0.0f, 0.0f,
		0.0f, 0.5f, -0.5f,		0.0f, 1.0f,		0.0f, 0.0f, 0.0f,


	};

	unsigned int luchadoresIndices[] = {
		0, 2, 1,
		1, 2, 3
	};

	GLfloat luchadoresVertices[] = {
		-1.0f, 0.0f, -1.0f,	1.0f, 1.0f,	0.0f, -1.0f, 0.0f,
		1.0f, 0.0f, -1.0f,	1.0f, 0.0f,	0.0f, -1.0f, 0.0f,
		-1.0f, 0.0f, 1.0f,	0.0f, 1.0f,	0.0f, -1.0f, 0.0f,
		1.0f, 0.0f, 1.0f,	0.0f, 0.0f,	0.0f, -1.0f, 0.0f
	};
	
	Mesh *obj1 = new Mesh();
	obj1->CreateMesh(vertices, indices, 32, 12);
	meshList.push_back(obj1);

	Mesh *obj2 = new Mesh();
	obj2->CreateMesh(vertices, indices, 32, 12);
	meshList.push_back(obj2);

	Mesh *obj3 = new Mesh();
	obj3->CreateMesh(floorVertices, floorIndices, 32, 6);
	meshList.push_back(obj3);

	Mesh* obj4 = new Mesh();
	obj4->CreateMesh(vegetacionVertices, vegetacionIndices, 64, 12);
	meshList.push_back(obj4);

	Mesh* obj5 = new Mesh();
	obj5->CreateMesh(luchadoresVertices, luchadoresIndices, 32, 6);
	meshList.push_back(obj5);

	calcAverageNormals(indices, 12, vertices, 32, 8, 5);
	calcAverageNormals(vegetacionIndices, 12, vegetacionVertices, 64, 8, 5);

}


void CreateShaders()
{
	Shader *shader1 = new Shader();
	shader1->CreateFromFiles(vShader, fShader);
	shaderList.push_back(*shader1);
}

void CrearDado()
{
	// �ndices: 8 caras triangulares (cada cara usa 3 v�rtices �nicos)
	unsigned int octaedro_indices[] = {
	0, 1, 2, // cara 1
	3, 4, 5, // cara 2
	6, 7, 8, // cara 3
	9, 10, 11, // cara 4
	12, 13, 14, // cara 5
	15, 16, 17, // cara 6
	18, 19, 20, // cara 7
	21, 22, 23 // cara 8
	};

	// 24 v�rtices (3 por cara)
	// Formato: x, y, z, S, T, NX, NY, NZ
	GLfloat octaedro_vertices[] = {
		// --- CARA 1 --- (4)
		0.0f,  0.5f,  0.0f,  0.486328f, 0.755859f,  +0.577f, -0.577f, -0.577f,
		0.0f,  0.0f,  0.5f,  0.011719f, 0.755859f,  +0.577f, -0.577f, -0.577f,
	   -0.5f,  0.0f,  0.0f,  0.248047f, 0.994141f,  +0.577f, -0.577f, -0.577f,

	   // --- CARA 2 --- (1)
	   0.0f,  0.5f,  0.0f,  0.486328f, 0.746094f,  -0.577f, -0.577f, -0.577f,
	   0.5f,  0.0f,  0.0f,  0.250000f, 0.509766f,  -0.577f, -0.577f, -0.577f,
	   0.0f,  0.0f,  0.5f,  0.013672f, 0.746094f,  -0.577f, -0.577f, -0.577f,

	   // --- CARA 3 --- (8)
	   0.0f,  0.5f,  0.0f,  0.505859f, 0.744141f,  -0.577f, -0.577f, +0.577f,
	   0.0f,  0.0f, -0.5f,  0.744141f, 0.505859f,  -0.577f, -0.577f, +0.577f,
	   0.5f,  0.0f,  0.0f,  0.255859f, 0.505859f,  -0.577f, -0.577f, +0.577f,

	   // --- CARA 4 --- (5)
	   0.0f,  0.5f,  0.0f,  0.509766f, 0.746094f,  +0.577f, -0.577f, +0.577f,
	  -0.5f,  0.0f,  0.0f,  0.984375f, 0.746094f,  +0.577f, -0.577f, +0.577f,
	   0.0f,  0.0f, -0.5f,  0.748047f, 0.507812f,  +0.577f, -0.577f, +0.577f,

	   // --- CARA 5 --- (6)
	   0.0f, -0.5f,  0.0f,  0.490234f, 0.255859f,  -0.577f, +0.577f, -0.577f,
	   0.0f,  0.0f,  0.5f,  0.246094f, 0.496094f,  -0.577f, +0.577f, -0.577f,
	   0.5f,  0.0f,  0.0f,  0.009766f, 0.255859f,  -0.577f, +0.577f, -0.577f,

	   // --- CARA 6 --- (3)
	   0.0f, -0.5f,  0.0f,  0.498047f, 0.259766f,  -0.577f, +0.577f, +0.577f,
	   0.5f,  0.0f,  0.0f,  0.257812f, 0.500000f,  -0.577f, +0.577f, +0.577f,
	   0.0f,  0.0f, -0.5f,  0.738281f, 0.500000f,  -0.577f, +0.577f, +0.577f,

	   // --- CARA 7 --- (2)
	   0.0f, -0.5f,  0.0f,  0.507812f, 0.255859f,  +0.577f, +0.577f, +0.577f,
	  -0.5f,  0.0f,  0.0f,  0.986328f, 0.255859f,  +0.577f, +0.577f, +0.577f,
	   0.0f,  0.0f, -0.5f,  0.744141f, 0.494141f,  +0.577f, +0.577f, +0.577f,

	   // --- CARA 8 --- (7)
	   0.0f, -0.5f,  0.0f,  0.486328f, 0.248047f,  +0.577f, +0.577f, -0.577f,
	   0.0f,  0.0f,  0.5f,  0.011719f, 0.248047f,  +0.577f, +0.577f, -0.577f,
	  -0.5f,  0.0f,  0.0f,  0.250000f, 0.011719f,  +0.577f, +0.577f, -0.577f,
	};


	Mesh* dado = new Mesh();
	dado->CreateMesh(octaedro_vertices, octaedro_indices, 192, 36);
	meshList.push_back(dado);

}

int main()
{
	mainWindow = Window(1366, 768); // 1280, 1024 or 1024, 768
	mainWindow.Initialise();

	CreateObjects();
	CreateShaders();
	CrearDado();

	camera = Camera(glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f), -60.0f, 0.0f, 0.3f, 0.5f);

	brickTexture = Texture("Textures/brick.png");
	brickTexture.LoadTextureA();
	dirtTexture = Texture("Textures/dirt.png");
	dirtTexture.LoadTextureA();
	plainTexture = Texture("Textures/plain.png");
	plainTexture.LoadTextureA();
	pisoTexture = Texture("Textures/pisopf.png");
	pisoTexture.LoadTextureA();
	AgaveTexture = Texture("Textures/Agave.tga");
	AgaveTexture.LoadTextureA();
	dadoTexture = Texture("Textures/cubo8caras.png");
	dadoTexture.LoadTextureA();
	luchadorTexture = Texture("Textures/fam1.jpg");
	luchadorTexture.LoadTextureA();

	
	//Lamp_M = Model();
	//Lamp_M.LoadModel("Models/lampara.obj");
	Rico_M = Model();
	Rico_M.LoadModel("Models/ricolamp.obj");
	
	JessieLamp_M = Model();
	JessieLamp_M.LoadModel("Models/jessielamp.obj");
	JessieLamp2_M = Model();
	JessieLamp2_M.LoadModel("Models/jessielamp2.obj");

	//NUEVOS MODELOS
	Bala_M = Model();
	Bala_M.LoadModel("Models/bala.obj");
	Carl_M = Model();
	Carl_M.LoadModel("Models/carl.obj");
	Primo1_M = Model();
	Primo1_M.LoadModel("Models/primo1.obj");
	Primo2_M = Model();
	Primo2_M.LoadModel("Models/primo2.obj");
	Primo3_M = Model();
	Primo3_M.LoadModel("Models/primo3.obj");
	Arts_M = Model();
	Arts_M.LoadModel("Models/art1.obj");
	//Fin nuevos modelos
	
	Estante_M = Model();
	Estante_M.LoadModel("Models/estante.obj");
	
	/*
	//Personajes Brawl Stars
	Piper_M = Model();
	Piper_M.LoadModel("Models/piper.obj");
	Spike_M = Model();
	Spike_M.LoadModel("Models/spike.obj");
	Cordelius_M = Model();
	Cordelius_M.LoadModel("Models/cordelius.obj");
	Frank_M = Model();
	Frank_M.LoadModel("Models/frank.obj");
	Gus_M = Model();
	Gus_M.LoadModel("Models/gus.obj");
	Stu_M = Model();
	Stu_M.LoadModel("Models/stu.obj");
	Sam_M = Model();
	Sam_M.LoadModel("Models/sam.obj");
	Colette_M = Model();
	Colette_M.LoadModel("Models/colette.obj");
	Surge_M = Model();
	Surge_M.LoadModel("Models/surge.obj");
	Brock_M = Model();
	Brock_M.LoadModel("Models/brock.obj");
	Doug_M = Model();
	Doug_M.LoadModel("Models/doug.obj");
	SamYeti_M = Model();
	SamYeti_M.LoadModel("Models/samyeti.obj");
	SpikeFire_M = Model();
	SpikeFire_M.LoadModel("Models/spikefire.obj");
	SpikeSakura_M = Model();
	SpikeSakura_M.LoadModel("Models/spikesakura.obj");
	Dynamike_M = Model();
	Dynamike_M.LoadModel("Models/dynamike.obj");
	Gale_M = Model();
	Gale_M.LoadModel("Models/gale.obj");
	DougDraco_M = Model();
	DougDraco_M.LoadModel("Models/dougdraco.obj");
	Meg_M = Model();
	Meg_M.LoadModel("Models/meg.obj");
	Jessie_M = Model();
	Jessie_M.LoadModel("Models/jessie.obj");


	
	//Luchadores
	Luchador_M = Model();
	Luchador_M.LoadModel("Models/luchador.obj");
	Luchador2_M = Model();
	Luchador2_M.LoadModel("Models/resrler.obj");
	Luchador3_M = Model();
	Luchador3_M.LoadModel("Models/luchador3.obj");
	
	
	//Modelos animaci�n luchador
	Luchador3_M1 = Model();
	Luchador3_M1.LoadModel("Models/luchadorAnim80.obj");
	Luchador3_M2 = Model();
	Luchador3_M2.LoadModel("Models/luchadorAnim81.obj");
	Luchador3_M3 = Model();
	Luchador3_M3.LoadModel("Models/luchadorAnim82.obj");
	Luchador3_M4 = Model();
	Luchador3_M4.LoadModel("Models/luchadorAnim83.obj");
	Luchador3_M5 = Model();
	Luchador3_M5.LoadModel("Models/luchadorAnim84.obj");
	Luchador3_M6 = Model();
	Luchador3_M6.LoadModel("Models/luchadorAnim85.obj");
	Luchador3_M7 = Model();
	Luchador3_M7.LoadModel("Models/luchadorAnim86.obj");
	Luchador3_M8 = Model();
	Luchador3_M8.LoadModel("Models/luchadorAnim87.obj");
	Luchador3_M9 = Model();
	Luchador3_M9.LoadModel("Models/luchadorAnim88.obj");
	
	
	Pedestal_M = Model();
	Pedestal_M.LoadModel("Models/pedestal.obj");
	
	Carrito_M = Model();
	Carrito_M.LoadModel("Models/shop.obj");
	Mask_M = Model();
	Mask_M.LoadModel("Models/mask.obj");
	Mask2_M = Model();
	Mask2_M.LoadModel("Models/mask2.obj");
	Mask3_M = Model();
	Mask3_M.LoadModel("Models/mask3.obj");
	Mask4_M = Model();
	Mask4_M.LoadModel("Models/mask4.obj");
	Mask5_M = Model();
	Mask5_M.LoadModel("Models/mask5.obj");
	Bulls_M = Model();
	Bulls_M.LoadModel("Models/bulls.obj");
	Ochobit_M = Model();
	Ochobit_M.LoadModel("Models/8bit.obj");
	*/
	
	std::vector<std::string> skyboxFaces;
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_rt.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_lf.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_dn.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_up.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_bk.tga");
	skyboxFaces.push_back("Textures/Skybox/cupertin-lake_ft.tga");

	skybox = Skybox(skyboxFaces);

	Material_brillante = Material(4.0f, 256);
	Material_opaco = Material(0.3f, 4);


	//luz direccional, s�lo 1 y siempre debe de existir
	mainLight = DirectionalLight(1.0f, 1.0f, 1.0f,
		0.3f, 0.3f,
		0.0f, 0.0f, -1.0f);

	//POINT LIGHTS
	//contador de luces puntuales
	unsigned int pointLightCount = 0;
	//verde
	pointLights[0] = PointLight(0.0f, 1.0f, 0.0f,
		0.7f, 0.7f,
		-6.0f, 1.0f, 15.0f,
		0.3f, 0.3f, 0.3f);
	pointLightCount++;
	//azul
	pointLights[1] = PointLight(0.0f, 0.0f, 1.0f,
		0.7f, 0.7f,
		-3.0f, 1.0f, 18.0f,
		0.3f, 0.3f, 0.3f);
	pointLightCount++;
	//roja
	pointLights[2] = PointLight(1.0f, 0.0f, 1.0f,
		0.7f, 0.7f,
		0.0f, 1.0f, 21.0f,
		0.3f, 0.3f, 0.3f);
	pointLightCount++;
	
	// LUZ CORRESPONDIENTE A LA BALA DE JESSIE
	pointLights[3] = PointLight(0.0f, 0.0f, 1.0f, // Color: Azul puro (R:0, G:0, B:1)
		5.0f, 20.0f, // Intensidad: Aumentada (Ambiental de 2.5 a 5.0, Difusa de 12.0 a 20.0)
		0.0f, 2.5f, -8.0f,
		1.0f, 0.09f, 0.032f);
	pointLightCount++;

	//blanca
	pointLights[4] = PointLight(1.0f, 0.8f, 0.4f, //1.0 0.8 0.4
		2.0f, 2.0f,
		0.0f, 0.0f, 0.0f,  //0.0f, 2.5f, -8.0f,
		0.1f, 0.1f, 0.1f);
	pointLightCount++;
	

	//SPOT LIGHTS
	unsigned int spotLightCount = 0;
	//linterna
	spotLights[0] = SpotLight(1.0f, 1.0f, 1.0f,
		0.0f, 2.0f,
		0.0f, 0.0f, 0.0f,
		0.0f, -1.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		5.0f);
	spotLightCount++;
	//luz fija verde
	spotLights[1] = SpotLight(0.0f, 1.0f, 0.0f,
		1.0f, 2.0f,
		5.0f, 10.0f, 0.0f,
		0.0f, -5.0f, 0.0f,
		1.0f, 0.0f, 0.0f,
		15.0f);
	spotLightCount++;
	// Faro azul del coche
	spotLights[2] = SpotLight(
		0.0f, 0.0f, 1.0f,   // color azul (r,g,b)
		0.3f, 2.0f,         // intensidad ambiental y difusa
		0.0f, 0.0f, 0.0f,   // posici�n inicial (la actualizaremos en el loop)
		0.0f, 0.0f, 1.0f,   // direcci�n hacia adelante (eje Z)
		1.0f, 0.0f, 0.0f,   // atenuaci�n constante, lineal y cuadr�tica
		10.0f               // l�mite del �ngulo del cono (en grados)
	);
	spotLightCount++;
	// LUZ CORRSPONDIENTE AL FARO DE RICO
	spotLights[3] = SpotLight(
		1.0f, 0.8f, 0.4f,   // color amarillo (r,g,b)
		0.1f, 0.8f,         // intensidad ambiental y difusa
		0.0f, 0.0f, 0.0f,   // posici�n inicial (la actualizaremos en el loop)
		1.0f, 0.0f, 0.0f,   // direcci�n hacia abajo (eje -Y)
		1.0f, 0.0f, 0.0f,   // atenuaci�n constante, lineal y cuadr�tica
		30.0f               // l�mite del �ngulo del cono (en grados)
	);
	spotLightCount++;
	// LUZ CORRSPONDIENTE AL FARO DE CARL
	spotLights[4] = SpotLight(
		1.0f, 0.8f, 0.4f,   // color amarillo (r,g,b)
		0.1f, 0.8f,         // intensidad ambiental y difusa
		0.0f, 0.0f, 0.0f,   // posici�n inicial (la actualizaremos en el loop)
		0.0f, 0.0f, 1.0f,   // direcci�n hacia abajo (eje -Y)
		1.0f, 0.0f, 0.0f,   // atenuaci�n constante, lineal y cuadr�tica
		30.0f               // l�mite del �ngulo del cono (en grados)
	);
	spotLightCount++;
	// Spotlight hacia atr�s
	spotLights[5] = SpotLight(
		1.0f, 1.0f, 1.0f,
		0.3f, 1.0f,
		0.0f, 0.0f, 0.0f,
		1.0f, 0.0f, 0.0f,   // direcci�n hacia atr�s (X positiva)
		1.0f, 0.0f, 0.0f,
		15.0f
	);
	spotLightCount++;
	// Luz del cofre del auto (faro)
	spotLights[6] = SpotLight(
		0.627f, 0.125f, 0.941f,    // color blanco c�lido (similar a un faro hal�geno)
		0.4f, 2.0f,           // intensidades ambiental y difusa
		0.0f, 0.0f, 0.0f,    // posici�n (ligeramente por delante del auto)
		0.0f, -0.5f, 1.0f,    // direcci�n: un poco hacia abajo y al frente
		1.0f, 0.09f, 0.032f,  // atenuaci�n (constante, lineal, cuadr�tica)
		20.0f                 // �ngulo del cono (m�s amplio)
	);
	spotLightCount++;
	
	GLuint uniformProjection = 0, uniformModel = 0, uniformView = 0, uniformEyePosition = 0,
		uniformSpecularIntensity = 0, uniformShininess = 0;
	GLuint uniformColor = 0;
	glm::mat4 projection = glm::perspective(45.0f, (GLfloat)mainWindow.getBufferWidth() / mainWindow.getBufferHeight(), 0.1f, 1000.0f);

	glm::mat4 model(1.0);
	glm::mat4 modelaux(1.0);
	glm::vec3 color = glm::vec3(1.0f, 1.0f, 1.0f);
	glm::vec3 lowerLight = glm::vec3(0.0f, 0.0f, 0.0f);

	//VARIABLES
	// Auto
	// direcci�n del faro (hacia adelante en X)
	glm::vec3 faroDir = glm::vec3(-1.0f, -0.1f, 0.0f);
	glm::vec3 cofreDir = glm::vec3(-1.0f, 1.0f, 0.0f);
	//glm::vec3 autoDir = glm::vec3(-1.0f, 0.0f, 0.0f);
	
	// Helic�ptero
	// actualizar posici�n y direcci�n de la luz amarilla
	glm::vec3 faroDir2 = glm::vec3(0.0f, -1.0f, 0.0f);

	// posici�n de la l�mpara
	glm::vec3 lampPosition = glm::vec3(0.0f, -0.7f, -8.0f);

	
	// Luchador
	static float elapsedTime = 0.0f;
	static int currentFrame = 0;
	const int totalFrames = 9;       // cantidad de modelos (1 al 40)
	const float frameDuration = 10.0f; // segundos entre cada cambio (~12.5 FPS) 0.08f

	//NUEVAS VARIABLES PARA LAS ANIMACIONES
	//Primo
	float rotPrimo = 0.0f;
	float velRotPrimo = 10.0f; // Velocidad de rotaci�n en grados por segundo
	float targetRot = 0.0f; // <-- Nueva variable para el objetivo

	//Jessie
	// Variables para la animaci�n de la bala de Jessie
	float balaAvance = 0.0f;        // La distancia actual que ha recorrido la bala (0.0 a 10.0)
	float balaVelocidad = 1.0f;    // Velocidad de avance (unidades por segundo). Ajusta este valor.
	float balaDistanciaMax = 50.0f; // Distancia m�xima que recorrer�
	bool balaDisparada = false;     // Estado interno: TRUE si la bala ya sali� y est� en movimiento.

	////Loop mientras no se cierra la ventana
	while (!mainWindow.getShouldClose())
	{
		GLfloat now = glfwGetTime();
		deltaTime = now - lastTime;
		deltaTime += (now - lastTime) / limitFPS;
		lastTime = now;

		//Recibir eventos del usuario
		glfwPollEvents();
		camera.keyControl(mainWindow.getsKeys(), deltaTime);
		camera.mouseControl(mainWindow.getXChange(), mainWindow.getYChange());

		// Clear the window
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		skybox.DrawSkybox(camera.calculateViewMatrix(), projection);
		shaderList[0].UseShader();
		uniformModel = shaderList[0].GetModelLocation();
		uniformProjection = shaderList[0].GetProjectionLocation();
		uniformView = shaderList[0].GetViewLocation();
		uniformEyePosition = shaderList[0].GetEyePositionLocation();
		uniformColor = shaderList[0].getColorLocation();
		
		//informaci�n en el shader de intensidad especular y brillo
		uniformSpecularIntensity = shaderList[0].GetSpecularIntensityLocation();
		uniformShininess = shaderList[0].GetShininessLocation();

		glUniformMatrix4fv(uniformProjection, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix4fv(uniformView, 1, GL_FALSE, glm::value_ptr(camera.calculateViewMatrix()));
		glUniform3f(uniformEyePosition, camera.getCameraPosition().x, camera.getCameraPosition().y, camera.getCameraPosition().z);
		
		// luz ligada a la c�mara de tipo flash
		//sirve para que en tiempo de ejecuci�n (dentro del while) se cambien propiedades de la luz
		glm::vec3 lowerLight = camera.getCameraPosition();
		lowerLight.y -= 0.3f;
		spotLights[0].SetFlash(lowerLight, camera.getCameraDirection());

		//Enviar luz al shader
		shaderList[0].SetDirectionalLight(&mainLight);
		shaderList[0].SetPointLights(pointLights, pointLightCount);
		//shaderList[0].SetSpotLights(spotLights, spotLightCount);

		// Manejo de PointLights
		//PointLight activePointLights[MAX_POINT_LIGHTS];
		//unsigned int activePointCount = 0;
		// Slots 0, 1, 2: Luces fijas (verde, azul, roja). Se asume que siempre est�n encendidas.
		//activePointLights[activePointCount++] = pointLights[0];
		//activePointLights[activePointCount++] = pointLights[1];
		//activePointLights[activePointCount++] = pointLights[2];
		// Slot 3: Luz del Modelo Rico (amarilla)
		//if (mainWindow.getrico()) {
		//	activePointLights[activePointCount++] = pointLights[3];
		//}
		// Slot 4: Luz de la Antorcha/L�mpara (blanca)
		//if (mainWindow.getprendida()) {
		//	activePointLights[activePointCount++] = pointLights[4];
		//}
		// Enviar las point lights activas
		//shaderList[0].SetPointLights(activePointLights, activePointCount);

		// Manejo de SpotLights
				SpotLight activeSpotLights[MAX_SPOT_LIGHTS];
		unsigned int activeSpotCount = 0;
		activeSpotLights[activeSpotCount++] = spotLights[0];
		activeSpotLights[activeSpotCount++] = spotLights[1];
		activeSpotLights[activeSpotCount++] = spotLights[2];
		if (mainWindow.getrico()) { // Luz rico proyecto 1
			activeSpotLights[activeSpotCount++] = spotLights[3];
		}
		if (mainWindow.getcarl()) { // Luz rico proyecto 1
			activeSpotLights[activeSpotCount++] = spotLights[4];
		}
		activeSpotLights[activeSpotCount++] = spotLights[5];
		activeSpotLights[activeSpotCount++] = spotLights[6];
		// Enviamos el arreglo de luces activas al shader
		shaderList[0].SetSpotLights(activeSpotLights, activeSpotCount);

		//Piso
		color = glm::vec3(1.0f, 1.0f, 1.0f);
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(0.0f, -1.0f, 0.0f));
		model = glm::scale(model, glm::vec3(30.0f*0.788f, 1.0f, 30.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));
		pisoTexture.UseTexture();
		Material_opaco.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[2]->RenderMesh();
		
		//NUEVA SECCI�N DE ANIMACIONES
		//Primo Animaci�n
		if (mainWindow.getanimprimo()){
			targetRot = 0.0f;
		}
		else{
			targetRot = -90.0f;
		}
		// 2. Mover la rotaci�n actual (rotPrimo) hacia el objetivo
		float diff = targetRot - rotPrimo;
		if (std::abs(diff) > 0.01f){
			// Determinar la direcci�n del movimiento (+ o -)
			float direction = (diff > 0) ? 1.0f : -1.0f;
			float step = velRotPrimo * deltaTime * direction;
			// Si el paso nos va a hacer pasar del objetivo, forzar a que sea el objetivo
			if (std::abs(step) > std::abs(diff)){
				rotPrimo = targetRot;
			}
			else{
				// Aplicar el paso de rotaci�n
				rotPrimo += step;
			}
		}

		//Animacion Jessie
		if (mainWindow.getanimjessie()) // El trigger (tecla presionada)
		{
			// Si la bala NO ha sido disparada a�n, la activamos y reiniciamos el avance
			if (!balaDisparada)
			{
				balaDisparada = true; // La bala est� en el aire
				balaAvance = 0.0f;     // Reiniciamos la posici�n para el nuevo disparo
			}
		}
		// ELSE: No necesitamos l�gica en el 'else' si el disparo es un pulso.
		// El control de avance se maneja a continuaci�n:

		// --- Control de Avance y Detenci�n ---

		if (balaDisparada)
		{
			// 1. Calcular el movimiento gradual para este frame
			float deltaAvance = balaVelocidad * deltaTime;

			// 2. Comprobar si al aplicar el paso excederemos la distancia m�xima
			if (balaAvance + deltaAvance >= balaDistanciaMax)
			{
				// Forzar a que la posici�n sea la final y desactivar el movimiento
				balaAvance = balaDistanciaMax;
				balaDisparada = false;       // La bala ha llegado a su destino
			}
			else
			{
				// La bala contin�a avanzando
				balaAvance += deltaAvance;
			}
		}
		//FIN NUEVA SECCI�N DE ANIMACIONES

		//Antorchas
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(119.1456f, -0.7f, -70.6f));
		pointLights[4].SetPos(glm::vec3(model[3].x, model[3].y + 14.0f, model[3].z));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Lamp_M.RenderModel();
		//Antocha 2
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(62.4096f, -0.7f, 25.2f));
		pointLights[4].SetPos(glm::vec3(model[3].x, model[3].y + 14.0f, model[3].z));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Lamp_M.RenderModel();
		//Antocha 3
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(62.4096f, -0.7f, 252.0f));
		pointLights[4].SetPos(glm::vec3(model[3].x, model[3].y + 14.0f, model[3].z));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Lamp_M.RenderModel();
		//Antocha 4
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-91.2504f, -0.7f, 252.0f));
		pointLights[4].SetPos(glm::vec3(model[3].x, model[3].y + 14.0f, model[3].z));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Lamp_M.RenderModel();

		//NUEVOS MODELOS
		//Rico Lamp
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(73.0f, -1.0f, -245.0));
		model = glm::rotate(model, -90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		spotLights[3].SetPos(glm::vec3(model[3].x, model[3].y + 30.0f, model[3].z));
		model = glm::scale(model, glm::vec3(3.0f, 3.0f, 3.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Rico_M.RenderModel();
		
		//Jessie Lamp
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(213.0f, -1.0f, -242.0));
		model = glm::rotate(model, 70 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::scale(model, glm::vec3(3.0f, 3.0f, 3.0f));
		modelaux = model;
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		JessieLamp_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(1.1f, 4.6908f, -0.040381f));
		model = glm::rotate(model, 45 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f)); //Animacion gira 45 grados en X
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		JessieLamp2_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(2.2713f, 5.8858f, -8.515f - balaAvance));
		model = glm::rotate(model, 45 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f)); //Animacion gira 45 grados en X
		pointLights[3].SetPos(glm::vec3(model[3].x, model[3].y, model[3].z));
		model = glm::scale(model, glm::vec3(0.2f, 0.2f, 0.2f)); 
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Bala_M.RenderModel(); // Renderizar el modelo de la bala

		//Carl
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(147.0f, 42.0f, -280.0));
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		spotLights[4].SetPos(glm::vec3(model[3].x, model[3].y + 5.0f, model[3].z));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Carl_M.RenderModel();

		//Primo animaci�n
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(210.0f, -1.0f, 271.2));
		model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));
		modelaux = model;
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Primo1_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(2.9201f*1.0f, 7.9955f*1.0f, 0.97337f*1.0f));
		model = glm::rotate(model, (90.0f + rotPrimo) * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Primo3_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-4.6632f*1.0f, 6.6226f*1.0f, 0.44056f*2.0f));
		model = glm::rotate(model, (83.0f + rotPrimo * 0.5f) * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Primo2_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Arts_M.RenderModel();
		//FIN NUEVOS MODELOS

		//Estante
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(130.0f, -13.0f, -300.0));
		model = glm::scale(model, glm::vec3(50.0f, 50.0f, 50.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		modelaux = model;
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Estante_M.RenderModel();
		//Estante2
		model = modelaux;
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, 1.7));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Estante_M.RenderModel();
		//Objetos estante1
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(73.0f, 22.6f, -280.0));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		modelaux = model;
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Rico_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(0.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Piper_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-16.0f, 0.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Spike_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-32.0f, 0.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Cordelius_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-48.0f, 0.0f, 0.0));
		model = glm::scale(model, glm::vec3(0.7f, 0.7f, 0.7f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Frank_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-64.0f, 0.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Gus_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-16.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Stu_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-32.0f, -19.4f, 0.0));
		model = glm::scale(model, glm::vec3(0.8f, 0.8f, 0.8f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Sam_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-48.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Colette_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-64.0f, -19.4f, 0.0));
		model = glm::scale(model, glm::vec3(0.7f, 0.7f, 0.7f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Surge_M.RenderModel();
		//Objetos estante2
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(158.0f, 22.6f, -280.0));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		modelaux = model;
		model = glm::rotate(model, -90 * toRadians, glm::vec3(1.0f, 0.0f, 0.0f));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 0.0f, 1.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Brock_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(0.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Doug_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-16.0f, 0.0f, 0.0));
		model = glm::scale(model, glm::vec3(0.8f, 0.8f, 0.8f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		SamYeti_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-32.0f, 0.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		SpikeFire_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-48.0f, 0.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		SpikeSakura_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-64.0f, 0.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Dynamike_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-16.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Gale_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-32.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		DougDraco_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-48.0f, -19.4f, 0.0));
		model = glm::scale(model, glm::vec3(0.8f, 0.8f, 0.8f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Meg_M.RenderModel();
		model = modelaux;
		model = glm::translate(model, glm::vec3(-64.0f, -19.4f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Jessie_M.RenderModel();
		
		//Pedestal
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-173.0f, -1.5f, -275.0));
		modelaux = model;
		model = glm::scale(model, glm::vec3(4.25f, 4.25f, 4.25f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Pedestal_M.RenderModel();
		model = modelaux;
		model = glm::scale(model, glm::vec3(0.1f, 0.1f, 0.1f));
		model = glm::translate(model, glm::vec3(0.0f, 192.0f, -25.0));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Luchador_M.RenderModel();
		//Pedestal2
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-143.0f, -1.5f, -275.0));
		modelaux = model;
		model = glm::scale(model, glm::vec3(4.25f, 4.25f, 4.25f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Pedestal_M.RenderModel();
		model = modelaux;
		model = glm::scale(model, glm::vec3(0.1f, 0.1f, 0.1f));
		model = glm::translate(model, glm::vec3(0.0f, 192.0f, 0.0));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Luchador2_M.RenderModel();
		//Pedestal3
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-113.0f, -1.5f, -275.0));
		modelaux = model;
		model = glm::scale(model, glm::vec3(4.25f, 4.25f, 4.25f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Pedestal_M.RenderModel();
		model = modelaux;
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		model = glm::translate(model, glm::vec3(0.0f, 19.35f, 0.0));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Luchador3_M.RenderModel();

		//Animaci�n Luchador
		// Actualizar tiempo
		elapsedTime += deltaTime; // Aseg�rate de tener tu deltaTime calculado
		if (elapsedTime >= frameDuration) {
			elapsedTime = 0.0f;
			currentFrame++;
			if (currentFrame >= totalFrames)
				currentFrame = 0;
		}
		// Matriz de transformaci�n
		model = glm::mat4(1.0f);
		model = glm::translate(model, glm::vec3(-203.0f, 0.0f, -250.0));
		model = glm::scale(model, glm::vec3(15.0f, 15.0f, 15.0f));
		model = glm::rotate(model, -90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		// Dibujar el modelo actual (seg�n frame)
		switch (currentFrame) {
		case 0:  Luchador3_M1.RenderModel(); break;
		case 1:  Luchador3_M2.RenderModel(); break;
		case 2:  Luchador3_M3.RenderModel(); break;
		case 3:  Luchador3_M4.RenderModel(); break;
		case 4:  Luchador3_M5.RenderModel(); break;
		case 5:  Luchador3_M6.RenderModel(); break;
		case 6:  Luchador3_M7.RenderModel(); break;
		case 7:  Luchador3_M8.RenderModel(); break;
		case 8:  Luchador3_M9.RenderModel(); break;
		}

		//Letrero luchador
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(-143.0f, -0.95f, -235.0));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::scale(model, glm::vec3(15.0f, 15.0f, 30.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		color = glm::vec3(1.0f, 1.0f, 1.0f);
		glUniform3fv(uniformColor, 1, glm::value_ptr(color));
		luchadorTexture.UseTexture();
		Material_brillante.UseMaterial(uniformSpecularIntensity, uniformShininess);
		meshList[4]->RenderMesh();

		//Tienda mask
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(62.4096f, -1.0f, -123.0f));
		model = glm::scale(model, glm::vec3(8.0f, 8.0f, 8.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Carrito_M.RenderModel();
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(66.192f, 21.1f, -118.8f));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Mask_M.RenderModel();
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(61.464f, 20.5f, -118.8f));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Mask2_M.RenderModel();
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(64.7736f, 20.5f, -124.8f));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Mask3_M.RenderModel();
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(68.0832f, 20.5f, -131.4f));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Mask4_M.RenderModel();
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(69.5016f, 21.1f, -126.0f));
		model = glm::scale(model, glm::vec3(10.0f, 10.0f, 10.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Mask5_M.RenderModel();

		//Bulls
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(47.3008f, -2.0f, 20.0));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		model = glm::scale(model, glm::vec3(6.0f, 6.0f, 6.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Bulls_M.RenderModel();
		glDisable(GL_BLEND);
		//NPC2
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(60.9912f, -1.0f, 96.4));
		model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		model = glm::rotate(model, 90 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Ochobit_M.RenderModel();

		//blending: transparencia o traslucidez
		//glEnable(GL_BLEND);
		//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		//AgaveTexture.UseTexture();
		//Material_opaco.UseMaterial(uniformSpecularIntensity, uniformShininess);
		//meshList[3]->RenderMesh();
		//glDisable(GL_BLEND);

		glUseProgram(0);

		mainWindow.swapBuffers();
	}

	return 0;
}

/*
		glEnable(GL_BLEND);
		model = glm::mat4(1.0);
		model = glm::translate(model, glm::vec3(0.0f, 0.0f, 0.0));
		//model = glm::translate(model, glm::vec3(-213.0f, -1.0f, -242.0));
		//model = glm::scale(model, glm::vec3(1.0f, 1.0f, 1.0f));
		//model = glm::rotate(model, 180 * toRadians, glm::vec3(0.0f, 1.0f, 0.0f));
		glUniformMatrix4fv(uniformModel, 1, GL_FALSE, glm::value_ptr(model));
		Vitrina_M.RenderModel();
		glDisable(GL_BLEND);
*/
